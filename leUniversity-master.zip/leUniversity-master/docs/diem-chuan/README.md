---
sidebar: false
---

# Tổng hợp điểm chuẩn Đại học

## Mới nhất (2021)
Điểm chuẩn trúng tuyển Đại học theo phương thức xét học bạ THPT và xét điểm thi Đánh giá năng lực:
- [Khu vực TP. Hà Nội](2021/hanoi/README.md)
- Khu vực TP. Hồ Chí Minh
- Khu vực khác

Điểm chuẩn trúng tuyển Đại học theo phương thức xét điểm thi tốt nghiệp THPT năm 2021:
- Khu vực TP. Hà Nội
- Khu vực TP. Hồ Chí Minh
- Khu vực khác

## Lưu trữ
- 2020
- 2019
- 2018