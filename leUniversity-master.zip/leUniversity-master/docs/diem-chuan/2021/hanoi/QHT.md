# Đại học Khoa Học Tự Nhiên 

|TT|Mã xét tuyển|Tên ngành|Điểm chuẩn|
|--- |--- |--- |--- |
|1|QHT01|Toán học|90,0|
|2|QHT02|Toán tin|100,0|
|3|QHT40|Máy tính   và khoa học thông tin**|100,0|
|4|QHT93|Khoa học   dữ liệu*|100,0|
|5|QHT03|Vật lý học|90,0|
|6|QHT04|Khoa học   vật liệu|90,0|
|7|QHT05|Công nghệ   kỹ thuật hạt nhân|90,0|
|8|QHT94|Kỹ thuật   điện tử và tin học*|100,0|
|9|QHT06|Hoá học|90,0|
|10|QHT41|Hoá học***|85,0|
|11|QHT42|Công nghệ   kỹ thuật hoá học**|85,0|
|12|QHT43|Hoá dược**|85,0|
|13|QHT08|Sinh học|85,0|
|14|QHT44|Công nghệ   sinh học**|85,0|
|15|QHT10|Địa lý tự   nhiên|80,0|
|16|QHT91|Khoa học   thông tin địa không gian*|80,0|
|17|QHT12|Quản lý   đất đai|80,0|
|18|QHT95|Quản lý   phát triển đô thị và bất động sản*|80,0|
|19|QHT13|Khoa học   môi trường|80,0|
|20|QHT46|Công nghệ   kỹ thuật môi trường**|80,0|
|21|QHT96|Khoa học   và công nghệ thực phẩm*|85,0|
|22|QHT16|Khí tượng   và khí hậu học|80,0|
|23|QHT17|Hải dương   học|80,0|
|24|QHT92|Tài   nguyên và môi trường nước*|80,0|
|25|QHT18|Địa chất   học|80,0|
|26|QHT20|Quản lý   tài nguyên và môi trường|80,0|
|27|QHT97|Công nghệ   quan trắc và giám sát tài nguyên môi trường*|80,0|
