# Đại học Kiến trúc

TT
	
Ngành/Chuyên ngành
	
Mã ngành
	
Điểm trúng tuyển
1
	
Công nghệ kỹ thuật vật liệu xây dựng
	
7510105
	
19
2
	
Xây dựng công trình ngầm đô thị
	
7580201_1
	
19
3
	
Quản lý dự án xây dựng
	
7580201_2
	
21
4
	
Kỹ thuật xây dựng công trình giao thông
	
7580205
	
18
5
	
Kỹ thuật hạ tầng đô thị
	
7580210
	
18
6
	
Kỹ thuật môi trường đô thị
	
7580210_1
	
18
7
	
Công nghệ cơ điện công trình
	
7580210_2
	
18
8
	
Kỹ thuật cấp thoát nước  
	
7580213
	
18