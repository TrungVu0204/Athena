# Tổng hợp điểm chuẩn Đại học 2021

Điểm chuẩn trúng tuyển Đại học theo phương thức xét học bạ THPT và xét điểm thi Đánh giá năng lực:
- [Khu vực TP. Hà Nội](hanoi/)
- Khu vực TP. Hồ Chí Minh
- Khu vực khác

Điểm chuẩn trúng tuyển Đại học theo phương thức xét điểm thi tốt nghiệp THPT năm 2021:
- Khu vực TP. Hà Nội
- Khu vực TP. Hồ Chí Minh
- Khu vực khác