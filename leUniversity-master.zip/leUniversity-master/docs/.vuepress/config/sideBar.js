module.exports = {
	'/dai-hoc/mien-bac': [
		{
			text: "Miền Bắc",
			link: "/dai-hoc/mien-bac",
			children: [
				"/dai-hoc/mien-bac/QH",
			],
		},
		{
			text: "Miền Nam",
			link: "/dai-hoc/mien-nam",
		},
	],
	'/dai-hoc/mien-nam': [
		{
			text: "Miền Bắc",
			link: "/dai-hoc/mien-bac",
		},
		{
			text: "Miền Nam",
			link: "/dai-hoc/mien-nam",
			children: [

			],
		},
	],
	'/diem-chuan/': 'auto',
};