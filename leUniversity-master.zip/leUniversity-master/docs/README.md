---
home: true
title: "Trang chủ"
tagline: "Cổng thông tin đại học"
heroImage: /images/hero.png
footer: MIT Licensed | Copyright © Catouberos

landingButton:
  - title: "Tìm trường"
    description: "Xem lựa chọn Đại học, Cao đẳng hoặc Du học"
    link: /truong/
  - title: "Điểm chuẩn"
    description: "Điểm chuẩn thi vào các trường mới nhất"
    link: /diem-chuan/
  - title: "Khối thi Đại học"
    description: "Các khối thi Đại học và môn thi"
    link: /nganh-hoc/khoi-thi.md
  - title: "Thủ tục / hồ sơ"
    description: "Một số thủ tục và hồ sơ cần thiết để bắt đầu"
    link: /thu-tuc-ho-so/
  - title: "Công cụ tính điểm"
    description: "Nhập và tính điểm xét tuyển ưu tiên Đại học"
    link: /cong-cu/tinh-diem.md
  - title: "Tin tức"
    description: "Các tin tức cập nhật về tuyển sinh, du học"
    link: /tin-tuc
---

<LandingAction />