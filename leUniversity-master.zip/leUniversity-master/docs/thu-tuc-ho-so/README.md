---
sidebar: false
---

# Thủ tục và Hồ sơ

Một số thủ tục & hồ sơ cần thiết

Những quy định chung
* [Điều chỉnh lịch tuyển sinh và hướng dẫn xét tuyển thí sinh đặc cách tốt nghiệp năm 2021](dieu-chinh-lich-tuyen-sinh.md)
* Hướng dẫn tổ chức kỳ thi tốt nghiệp THPT năm 2021 đợt 2
* Hướng dẫn tổ chức kỳ thi tốt nghiệp THPT năm 2021
* Danh sách 65 Hội đồng thi tốt nghiệp THPT năm 2021
* Sửa đổi, bổ sung Quy chế tuyển sinh ĐH, CĐ ngành GDMN (Ban hành ngày 01/06/2021)
* Điều chỉnh thời gian tuyển sinh ĐH, CĐSP năm 2020 (Ban hành ngày 28/08/2020)
* Quy chế thi tốt nghiệp trung học phổ thông (Ban hành ngày 26/5/2020)
* Quy chế tuyển sinh đại học, cao đẳng ngành GDMN năm 2020 (ban hành ngày 7/5/2020) 
* Lịch thi tốt nghiệp THPT và xét tuyển Đại học, Cao đẳng năm 2021 
* Sửa đổi, bổ sung một số điều của Quy chế tuyển sinh đại học hệ chính quy... (ban hành ngày 28/02/2019) 