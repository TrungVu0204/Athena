---
sidebar: false
landingButton:
  - title: "Đại học"
    link: /dai-hoc/
  - title: "Cao đẳng"
    link: /cao-dang/
  - title: "Du học"
    link: /du-hoc/
---

# Tìm trường

Bạn muốn học Đại học hoặc Cao đẳng? Hoặc thậm chí đi du học?

Chưa biết điểm khác biệt? [Tìm hiểu tại đây](dai-hoc-vs-cao-dang.md).

<LandingAction />