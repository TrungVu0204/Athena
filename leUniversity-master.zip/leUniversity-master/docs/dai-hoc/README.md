---
sidebar: false
landingButton:
  - title: "Miền Bắc"
    link: mien-bac/
  - title: "Miền Trung"
    link: mien-trung/
  - title: "Miền Nam"
    link: mien-nam/
---

# Đại học

le đại học là gì...

<LandingAction />