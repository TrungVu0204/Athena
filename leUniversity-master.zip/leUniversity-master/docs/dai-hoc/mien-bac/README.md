# Đại học Hà Nội

| Mã trường  | Tên trường |
|--- |--- |
|QH|[Đại học Quốc gia Hà Nội](./QH.md)|
|QHI|Trường Đại học Công nghệ - ĐHQG Hà Nội|
|QHT|Trường ĐH Khoa học Tự nhiên - ĐHQG Hà Nội|
|QHX|Trường ĐH Khoa học Xã hội và Nhân văn - ĐHQG Hà Nội|
|QHE|Trường Đại học Kinh tế - ĐHQG Hà Nội|
|QHF|Trường Đại học Ngoại ngữ - ĐHQG Hà Nội|
|QHL|Khoa Luật - ĐHQG Hà Nội|
|QHS|Trường ĐH Giáo dục - ĐHQG Hà Nội|
|QHY|Trường Đại học Y Dược - ĐHQG Hà Nội|
|QHQ|Khoa Quốc tế - ĐHQG Hà Nội|
|QHJ|Trường Đại học Việt Nhật - ĐHQG Hà Nội|
|NVH|Học viện Âm nhạc Quốc gia Việt Nam|
|TGC|Học viện Báo chí Tuyên truyền|
|HCP|Học viện Chính sách và Phát triển|
|BVH|Học viện Công nghệ Bưu chính Viễn thông|
|HCH|Học viện Hành chính Quốc gia|
|KMA|Học viện Kỹ thuật Mật mã|
|NHH|Học viện Ngân hàng|
|HQT|Học viện Ngoại giao|
|HVN|Học viện Nông nghiệp Việt Nam|
|HPN|Học viện Phụ nữ Việt Nam|
|HVQ|Học viện Quản lý Giáo dục|
|HTC|Học viện Tài chính|
|HTN|Học viện Thanh Thiếu niên Việt Nam|
|HTA|Học viện Tòa án|
|HYD|Học viện Y Dược học cổ truyền Việt Nam|
|BKA|Trường Đại học Bách khoa Hà Nội|
|LDA|Trường Đại học Công đoàn|
|GTA|Trường Đại học Công nghệ Giao thông vận tải|
|CCM|Trường Đại học Công nghiệp Dệt may Hà Nội|
|DCN|Trường Đại học Công nghiệp Hà Nội|
|VHD|Trường Đại học Công nghiệp Việt Hung|
|DKH|Trường Đại học Dược Hà Nội|
|DDL|Trường Đại học Điện lực|
|GHA|Trường Đại học Giao thông vận tải|
|NHF|Trường Đại học Hà Nội|
|KCN|Trường Đại học Khoa học và Công nghệ Hà Nội|
|DKK|Trường Đại học Kinh tế Kỹ thuật Công nghiệp|
|KHA|Trường Đại học Kinh tế Quốc dân|
|DKS|Trường Đại học Kiểm sát Hà Nội|
|KTA|Trường Đại học Kiến trúc Hà Nội|
|DLX|Trường Đại học Lao động Xã hội|
|LNH|Trường Đại học Lâm nghiệp|
|LPH|Trường Đại học Luật Hà Nội|
|MDA|Trường Đại học Mỏ Địa chất Hà Nội|
|MHN|Trường Đại học Mở Hà Nội|
|MTC|Trường Đại học Mỹ thuật Công nghiệp|
|MCA|Trường Đại học Mỹ thuật Công nghiệp Á Châu (*)|
|MTH|Trường Đại học Mỹ thuật Việt Nam|
|NTH|Trường Đại học Ngoại thương|
|DNV|Trường Đại học Nội vụ Hà Nội|
|SKD|Trường Đại học Sân khấu Điện ảnh|
|SPH|Trường Đại học Sư phạm Hà Nội|
|GNT|Trường Đại học Sư phạm Nghệ thuật Trung ương Hà Nội|
|TDH|Trường Đại học Sư phạm Thể dục thể thao Hà nội|
|DMT|Trường Đại học Tài nguyên và Môi trường Hà Nội|
|HNM|Trường Đại học Thủ đô Hà Nội|
|TLA|Trường Đại học Thủy lợi|
|TMA|Trường Đại học Thương mại|
|VHH|Trường Đại học Văn hóa Hà Nội|
|XDA|Trường Đại học Xây dựng|
|YHB|Trường Đại học Y Hà Nội|
|YTC|Trường Đại học Y tế Công cộng|
|DDD|Trường Đại học Đông Đô (*)|
|DPD|Trường Đại học Phương Đông (*)|
|DTL|Trường Đại học Thăng Long (*)|
|DDN|Trường Đại học Đại Nam (*)|
|FPT|Trường Đại học FPT (*)|
|HBU|Trường Đại học Hòa Bình (*)|
|DQK|Trường Đại học Kinh doanh và Công nghệ Hà Nội (*)|
|NTU|Trường Đại học Nguyễn Trãi (*)|
|FBU|Trường Đại học Tài chính Ngân hàng Hà Nội (*)|
|PKA|Trường Đại học Phenikaa (*)|
|TDD|Trường Đại học Thành Đô (*)|
|DCQ|Trường Đại học Công nghệ và Quản lý Hữu nghị (*)|